<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Models\PlanterBox;
use App\Models\Plant;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/api/planter-boxes', function () {
    return PlanterBox::with('plant')->orderBy('position')->get();
});

Route::get('/api/plants', function () {
    return Plant::with('varieties')->get();
});

// Optionally, add a route to update a plant in a box
Route::post('/api/planter-boxes/{box}', function (Request $request, PlanterBox $box) {
    $box->plant_id = $request->input('plant_id');
    $box->save();
    return $box->load('plant');
});
